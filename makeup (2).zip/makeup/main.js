// make aoi call 

//   function appenddata (data){
//     let parent =  document.getElementById("main")

//     data.forEach(Element  => {

//         let div = document.createElement("div")

//         let images = document.createElement("img")
//         images.src = Element.api_featured_image
        
        
//         let text = document.createElement("txt")
//         text.innerText = Element.name

//         div.append( images , text)

//         parent.append (div)

//     })
//   }

// export  {apicall , appenddata}